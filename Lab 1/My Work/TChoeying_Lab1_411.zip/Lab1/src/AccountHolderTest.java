/*
 * Tenzin Choeying
 * 02.04.18
 * AccountHolderTest.java
 * Lab 1
 */

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Scanner;

public class AccountHolderTest {
	public static void main(String[]args) {
		Scanner scan = new Scanner(System.in);
		boolean valid = false;
		double initialBalance=0.0;

		//Ask user for initial Balance 
		while(!valid) {
			System.out.print("Please enter an Initial Account Balance: ");
			if (scan.hasNextDouble()) {
				initialBalance = scan.nextDouble();
				if(initialBalance>0) {
					valid = true;
				}
				else {
					new AccountHolder(initialBalance);
				}
			}
			else {
				System.out.println("Initial Blanace must be a number.");
				scan.next();
			}
		}
		
		AccountHolder ah = new AccountHolder(initialBalance);

		//Ask user for deposit amount
		valid = false;
		while(!valid) {
			System.out.print("Please Enter a deposit amount: ");
			if (scan.hasNextDouble()) {
				ah.deposit(scan.nextDouble());
				valid = true;
			}
			else {
				System.out.println("Deposit amount must be a number.");
				scan.next();
			}
		}
		
		//Ask user for withdrawal amount
		valid = false;
		while(!valid) {
			System.out.print("Please enter a withdrawal amount: ");
			if(scan.hasNextDouble()) {
				double withdrawal = scan.nextDouble();
				if((ah.getBalance()-withdrawal)<100) {
					ah.withdrawal(withdrawal);
				}
				else {
					ah.withdrawal(withdrawal);
					valid = true;
				}
			}
			else {
				System.out.println("Withdrawal amount must be a number.");
				scan.next();
			}
		}
		
		//set initial interest to 4%
		AccountHolder.modifyMonthlyInterest(0.04);
		
		//output monthly interest over 12 months
		System.out.println("Balance Reports");
		System.out.println("Montly balances for one year at 4% interest");
		System.out.println("Balances:");
		System.out.printf("%-15.15s %-30.30s%n","Month","Balance w. Interest");
		System.out.printf("%-15.15s %-30.30s%n","Base",ah);
		for(int i=1;i<=12;i++) {
			ah.monthlyInterest();
			System.out.printf("%-15.15s %-30.30s%n","Month " + i + ":",ah);
		}
		
		//update interest amount to 4%
		AccountHolder.modifyMonthlyInterest(0.04);	
		
		//time stamp and name
		String timeStamp = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss").format(Calendar.getInstance().getTime());
		System.out.println("\nCur dt=" + timeStamp + "\nProgrammed by Tenzin Choeying\n");
	}
}
