
public abstract class Client {
	
	public abstract void readData(); //read file detail
	public abstract void processData(); //process file detail
	public abstract void printData(); //print file detail

}
